package com.roletset.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.content.Context;
import android.os.Build;

public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  web = new WebView(this);
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(true);
  web.getSettings().setDefaultTextEncodingName("UTF-8");
  web.setWebViewClient(new WebViewClient());
  web.setWebChromeClient(new WebChromeClient());
  web.addJavascriptInterface(new Object() {
   @JavascriptInterface public void print() { runOnUiThread(() -> {
    PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
    pm.print("ROLET SET", web.createPrintDocumentAdapter("ROLET SET"), new PrintAttributes.Builder().build());
   }); }
  }, "AndroidPrinter");
  setContentView(web);
  web.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
